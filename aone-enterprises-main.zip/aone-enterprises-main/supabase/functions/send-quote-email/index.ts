import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface QuoteRequest {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company?: string;
  requirements: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const quoteData: QuoteRequest = await req.json();
    console.log("Received quote request:", quoteData);

    // Send email to business owner
    const emailResponse = await resend.emails.send({
      from: "Aone Enterprises <onboarding@resend.dev>",
      to: ["your-email@example.com"], // Replace with your actual email
      subject: `New Quote Request from ${quoteData.firstName} ${quoteData.lastName}`,
      html: `
        <h2>New Security Quote Request</h2>
        <p><strong>Name:</strong> ${quoteData.firstName} ${quoteData.lastName}</p>
        <p><strong>Email:</strong> ${quoteData.email}</p>
        <p><strong>Phone:</strong> ${quoteData.phone}</p>
        ${quoteData.company ? `<p><strong>Company:</strong> ${quoteData.company}</p>` : ''}
        <p><strong>Security Requirements:</strong></p>
        <p>${quoteData.requirements}</p>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    // Send confirmation email to customer
    await resend.emails.send({
      from: "Aone Enterprises <onboarding@resend.dev>",
      to: [quoteData.email],
      subject: "Quote Request Received - Aone Enterprises",
      html: `
        <h2>Thank you for your quote request!</h2>
        <p>Dear ${quoteData.firstName},</p>
        <p>We have received your security quote request and will get back to you within 24 hours.</p>
        <p><strong>Your Request Details:</strong></p>
        <p>${quoteData.requirements}</p>
        <br>
        <p>Best regards,<br>Aone Enterprises Team</p>
      `,
    });

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-quote-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
