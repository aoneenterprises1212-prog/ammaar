import { Button } from "@/components/ui/button";
import { Shield, Menu } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import QuoteDialog from "./QuoteDialog";

const Header = () => {
  const [isQuoteDialogOpen, setIsQuoteDialogOpen] = useState(false);
  return (
    <header className="bg-white shadow-card sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-security-primary" />
            <div>
              <h1 className="text-xl font-bold text-security-dark">Aone Enterprises</h1>
              <p className="text-sm text-muted-foreground">Security Solutions</p>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#home" className="text-foreground hover:text-security-primary transition-colors">Home</a>
            <a href="#products" className="text-foreground hover:text-security-primary transition-colors">Products</a>
            <a href="#about" className="text-foreground hover:text-security-primary transition-colors">About</a>
            <a href="#contact" className="text-foreground hover:text-security-primary transition-colors">Contact</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="hero" className="hidden md:inline-flex" asChild>
              <Link to="/quote">Get Quote</Link>
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      <QuoteDialog 
        open={isQuoteDialogOpen} 
        onOpenChange={setIsQuoteDialogOpen} 
      />
    </header>
  );
};

export default Header;