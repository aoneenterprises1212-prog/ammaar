import { Button } from "@/components/ui/button";
import { Shield, Phone, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-security.jpg";

const Hero = () => {
  return (
    <section id="home" className="relative bg-gradient-to-br from-security-dark via-security-primary to-security-dark text-white overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="relative container mx-auto px-4 py-24 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Your Trusted Partner for
                <span className="text-security-accent"> Top-Quality Security</span> Solutions
              </h1>
              <p className="text-xl text-gray-200 leading-relaxed">
                At Aone Enterprises, we specialize in providing state-of-the-art security products tailored to meet your needs. 
                Secure your home, office, or commercial property with our advanced surveillance solutions.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="security" size="lg" className="group" asChild>
                <Link to="/quote">
                  Get Free Quote
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20" asChild>
                <a href="tel:8766741698">
                  <Phone className="mr-2 h-5 w-5" />
                  Call: 8766741698
                </a>
              </Button>
            </div>
            
            <div className="flex items-center space-x-6 pt-4">
              <div className="flex items-center space-x-2">
                <Shield className="h-6 w-6 text-security-accent" />
                <span className="text-sm">Expert Installation</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-6 w-6 text-security-accent" />
                <span className="text-sm">24/7 Support</span>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src={heroImage} 
                alt="Professional security systems and CCTV surveillance technology"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-security-primary/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;