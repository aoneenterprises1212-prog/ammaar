import { Shield } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-security-dark text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-security-accent" />
              <div>
                <h3 className="text-xl font-bold">Aone Enterprises</h3>
                <p className="text-sm text-gray-300">Security Solutions</p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Your trusted partner for top-quality security solutions. 
              We provide state-of-the-art surveillance and protection systems.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-gray-300">
              <li>CCTV Installation</li>
              <li>Access Control Systems</li>
              <li>Alarm Systems</li>
              <li>Smart Home Security</li>
              <li>Surveillance Accessories</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#home" className="hover:text-security-accent transition-colors">Home</a></li>
              <li><a href="#products" className="hover:text-security-accent transition-colors">Products</a></li>
              <li><a href="#about" className="hover:text-security-accent transition-colors">About</a></li>
              <li><a href="#contact" className="hover:text-security-accent transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-8 pt-8 text-center text-gray-300">
          <p>&copy; 2024 Aone Enterprises. All rights reserved. | Professional Security Solutions</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;