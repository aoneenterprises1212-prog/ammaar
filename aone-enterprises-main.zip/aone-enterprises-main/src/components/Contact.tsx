import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, Instagram, MapPin, Clock, Check } from "lucide-react";
import { useState } from "react";

const Contact = () => {
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccessDialog(true);
    toast({
      title: "Message Sent!",
      description: "Your message has been sent to AONE Enterprises. We'll get back to you soon!",
    });
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-security-dark to-security-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Get in Touch</h2>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Ready to secure your property with the best surveillance systems? 
            Contact us today for a free consultation and quote.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-security-accent/20 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-security-accent" />
                  </div>
                  <div>
                    <p className="font-semibold">Phone</p>
                    <a href="tel:8766741698" className="text-security-accent hover:underline">8766741698</a>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-security-accent/20 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-security-accent" />
                  </div>
                  <div>
                    <p className="font-semibold">Email</p>
                    <a href="mailto:aoneenterprises1212@gmail.com" className="text-security-accent hover:underline">
                      aoneenterprises1212@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-security-accent/20 rounded-full flex items-center justify-center">
                    <Instagram className="w-6 h-6 text-security-accent" />
                  </div>
                  <div>
                    <p className="font-semibold">Instagram</p>
                    <a href="#" className="text-security-accent hover:underline">@aoneenterprises_</a>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-security-accent/20 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-security-accent" />
                  </div>
                  <div>
                    <p className="font-semibold">Business Hours</p>
                    <p className="text-gray-200">Mon - Sat: 9:00 AM - 7:00 PM</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white text-2xl">Get a Free Quote</CardTitle>
              <p className="text-gray-200">Fill out the form below and we'll get back to you within 24 hours.</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      placeholder="First Name" 
                      required
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-security-accent"
                    />
                    <input 
                      type="text" 
                      placeholder="Last Name" 
                      required
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-security-accent"
                    />
                  </div>
                  <input 
                    type="email" 
                    placeholder="Email Address" 
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-security-accent"
                  />
                  <input 
                    type="tel" 
                    placeholder="Phone Number" 
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-security-accent"
                  />
                  <textarea 
                    placeholder="Tell us about your security requirements..."
                    rows={4}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-300 focus:outline-none focus:border-security-accent resize-none"
                  ></textarea>
                  <Button type="submit" className="w-full bg-security-accent text-security-dark hover:bg-security-accent/90 font-semibold py-3">
                    Send Message
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Success Dialog */}
        <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
          <DialogContent className="bg-white border-none p-0 max-w-md">
            <div className="text-center p-8">
              <div className="w-20 h-20 mx-auto mb-6 bg-black rounded-full flex items-center justify-center relative">
                <Check className="w-10 h-10 text-red-500" strokeWidth={3} />
              </div>
              <h3 className="text-2xl font-bold text-black mb-2">MESSAGE SENT TO</h3>
              <h4 className="text-xl font-bold text-red-600 mb-4">AONE ENTERPRISES</h4>
              <p className="text-gray-600 mb-6">
                Thank you for your message! We'll get back to you within 24 hours.
              </p>
              <Button 
                onClick={() => setShowSuccessDialog(false)}
                className="bg-black text-white hover:bg-gray-800"
              >
                Close
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
};

export default Contact;