import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Camera, Shield, Smartphone, Eye, Settings, AlertTriangle } from "lucide-react";
import cctvIcon from "@/assets/cctv-icon.png";
import accessControlIcon from "@/assets/access-control-icon.png";
import alarmIcon from "@/assets/alarm-icon.png";

const products = [
  {
    title: "CCTV Cameras",
    description: "Indoor/Outdoor, IP Cameras, Wireless, Dome, PTZ Cameras",
    icon: Camera,
    image: cctvIcon,
    features: ["HD Resolution", "Night Vision", "Motion Detection", "Remote Access"]
  },
  {
    title: "Access Control Systems",
    description: "Biometric Security Solutions, Smart Access Management",
    icon: Shield,
    image: accessControlIcon,
    features: ["Fingerprint Scanner", "Card Access", "Time Tracking", "Multi-user Support"]
  },
  {
    title: "Alarm Systems",
    description: "Motion Detectors, Smart Home Security, Alert Systems",
    icon: AlertTriangle,
    image: alarmIcon,
    features: ["Instant Alerts", "Mobile App", "24/7 Monitoring", "Smart Integration"]
  },
  {
    title: "NVR & DVR Systems",
    description: "Recording and Storage Solutions for Surveillance",
    icon: Settings,
    features: ["Cloud Storage", "Local Recording", "Remote Playback", "Backup Systems"]
  },
  {
    title: "Smart Home Security",
    description: "Integrated Security Devices for Modern Homes",
    icon: Smartphone,
    features: ["Smart Locks", "Video Doorbells", "Security Sensors", "Mobile Control"]
  },
  {
    title: "Surveillance Accessories",
    description: "Professional Installation Hardware and Components",
    icon: Eye,
    features: ["Mounting Hardware", "Power Supplies", "Network Equipment", "Professional Tools"]
  }
];

const Products = () => {
  return (
    <section id="products" className="py-20 bg-security-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-security-dark mb-4">Our Security Products</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive range of surveillance and security solutions designed to provide reliable, 
            high-quality protection for residential and commercial properties.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <Card key={index} className="hover:shadow-card transition-all duration-300 hover:-translate-y-1 border-0 bg-white">
              <CardHeader className="text-center pb-4">
                <div className="mb-4 flex justify-center">
                  {product.image ? (
                    <img src={product.image} alt={product.title} className="w-16 h-16 object-contain" />
                  ) : (
                    <product.icon className="w-16 h-16 text-security-primary" />
                  )}
                </div>
                <CardTitle className="text-xl text-security-dark">{product.title}</CardTitle>
                <CardDescription className="text-muted-foreground">
                  {product.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {product.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-foreground">
                      <div className="w-2 h-2 bg-security-primary rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;