import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Wrench, Settings, Headphones, Award } from "lucide-react";

const features = [
  {
    icon: Wrench,
    title: "Expert Installation",
    description: "Our professional team ensures that your security products are installed seamlessly and efficiently with precision and care."
  },
  {
    icon: Settings,
    title: "Custom Solutions",
    description: "Tailored security systems designed to suit your specific requirements and property layout for maximum protection."
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "We're always here to help with any concerns, troubleshooting, or emergency support whenever you need us."
  },
  {
    icon: Award,
    title: "Reliable Brands",
    description: "We only offer products from trusted manufacturers known for their durability, performance, and cutting-edge technology."
  }
];

const WhyChooseUs = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-security-dark mb-4">Why Choose Aone Enterprises?</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We are committed to providing exceptional service and top-quality security solutions 
            that give you complete peace of mind.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center border-0 shadow-card hover:shadow-security transition-all duration-300 hover:-translate-y-1">
              <CardHeader className="pb-4">
                <div className="mx-auto mb-4 w-16 h-16 bg-gradient-to-br from-security-primary to-security-dark rounded-full flex items-center justify-center">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-security-dark">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;