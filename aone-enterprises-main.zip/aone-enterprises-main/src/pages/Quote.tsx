import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Shield, ArrowLeft, Phone, Mail, Clock } from "lucide-react";
import { Link } from "react-router-dom";

const Quote = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-security-dark to-security-primary">
      {/* Header */}
      <header className="bg-white shadow-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-security-primary" />
              <div>
                <h1 className="text-xl font-bold text-security-dark">Aone Enterprises</h1>
                <p className="text-sm text-muted-foreground">Security Solutions</p>
              </div>
            </Link>
            
            <Link to="/">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4">
              Get Your Free Security Quote
            </h1>
            <p className="text-xl text-gray-200 max-w-2xl mx-auto">
              Tell us about your security needs and we'll provide you with a customized quote 
              within 24 hours. No obligation, completely free.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Quote Form */}
            <div className="lg:col-span-2">
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-2xl text-security-dark">Request Your Quote</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name *</Label>
                        <Input id="firstName" placeholder="Enter your first name" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name *</Label>
                        <Input id="lastName" placeholder="Enter your last name" required />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address *</Label>
                        <Input id="email" type="email" placeholder="Enter your email" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input id="phone" type="tel" placeholder="Enter your phone number" required />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="company">Company Name</Label>
                      <Input id="company" placeholder="Enter your company name (optional)" />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="address">Property Address *</Label>
                      <Input id="address" placeholder="Enter the address where security is needed" required />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="propertyType">Property Type *</Label>
                      <select id="propertyType" className="w-full p-3 border border-gray-300 rounded-md" required>
                        <option value="">Select property type</option>
                        <option value="residential">Residential Home</option>
                        <option value="apartment">Apartment/Condo</option>
                        <option value="office">Office Building</option>
                        <option value="retail">Retail Store</option>
                        <option value="warehouse">Warehouse</option>
                        <option value="industrial">Industrial Facility</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="requirements">Security Requirements *</Label>
                      <Textarea 
                        id="requirements" 
                        placeholder="Please describe your security needs in detail:
• Areas to be covered
• Type of cameras needed (indoor/outdoor)
• Recording requirements
• Remote monitoring needs
• Budget range
• Installation timeline
• Any specific concerns or requirements"
                        className="min-h-[150px]"
                        required 
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="budget">Estimated Budget</Label>
                      <select id="budget" className="w-full p-3 border border-gray-300 rounded-md">
                        <option value="">Select budget range (optional)</option>
                        <option value="under-50k">Under ₹50,000</option>
                        <option value="50k-1l">₹50,000 - ₹1,00,000</option>
                        <option value="1l-2l">₹1,00,000 - ₹2,00,000</option>
                        <option value="2l-5l">₹2,00,000 - ₹5,00,000</option>
                        <option value="above-5l">Above ₹5,00,000</option>
                      </select>
                    </div>
                    
                    <Button type="submit" className="w-full bg-security-primary hover:bg-security-dark text-white py-3 text-lg">
                      Submit Quote Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Info Sidebar */}
            <div className="space-y-6">
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-security-dark">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-security-primary" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm text-muted-foreground">8766741698</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-security-primary" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm text-muted-foreground">contact@aoneenterprises.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-security-primary" />
                    <div>
                      <p className="font-medium">Business Hours</p>
                      <p className="text-sm text-muted-foreground">Mon-Sat: 9:00 AM - 7:00 PM</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-3 text-security-dark">What Happens Next?</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• We'll review your requirements within 24 hours</li>
                    <li>• Our security expert will contact you</li>
                    <li>• Free on-site consultation if needed</li>
                    <li>• Detailed quote with product recommendations</li>
                    <li>• Professional installation scheduling</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Quote;